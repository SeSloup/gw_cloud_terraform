#!/bin/bash

terraform apply -var-file="secret.tfvars"